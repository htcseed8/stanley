from openerp import models, fields, api


class feedback_employee(models.Model):

	_name = 'feedback.employee'
	_description='Employee Detials'
	
	emp_id=fields.Integer(string="Employee ID", required=True)
	emp_name=fields.Char(string="Employee Name",size=20, required=True)
	designation=fields.Char(string="designation", size=20,required =True)
	department=fields.Many2one('feedback.department',string='Deparment')
	branch=fields.Many2one('feedback.branch',string='Branch')
	role=fields.Many2one('feedback.role',string='Role')

class feedback_department(models.Model):

	_name = 'feedback.department'
	_description='Deparment'

	department_id=fields.Integer(string="Department ID",size=4, required=True)
	department_name=fields.Char(string="Department Name",size=20, required=True)

class feedback_branch(models.Model):

	_name = 'feedback.branch'
	_description='Branch'

	branch_id= fields.Integer(string="Branch ID", required=True)
	branch_name=fields.Char(string="Branch Name",size=20, required=True)

class feedback_role(models.Model):

	_name = 'feedback.role'
	_description='Role'

	role_id=fields.Integer(string="Role ID", required=True)
	role=fields.Char(string="Role",size=20, required=True)

class feedback_skills(models.Model):

	_name = 'feedback.skills'
	_description='Skills'

	#skill_id= fields.Integer(string="Skill ID", required=True)
	skill_name= fields.Char(string="Skill Name",size=20, required=True)
	
class feedback_batch(models.Model):

	_name = 'feedback.batch'
	_description='Batch'

	batch_id= fields.Integer(string="Batch ID", required=True)
	batch_name= fields.Char(string="Batch Name",size=20, required=True)
	trainer_allocate=fields.One2many('feedback.trainer.allocation','allocation_id',string='Trainer Allocation')
	batch_member=fields.One2many('feedback.employee','emp_id',string='Batch members')
	
class feedback_trainer_allocation(models.Model):

	_name = 'feedback.trainer.allocation'
	_description='Trainer Allocation'

	allocation_id= fields.Char(string="Skill",size=20, required=True)
	skill=fields.One2many('feedback.skill','skill_id',string='Skill')
	trainer=fields.One2many('feedback.employee','emp_id',string='Trainer')