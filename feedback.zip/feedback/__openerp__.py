{
    'name': 'Feedback Management',
    'version': '1.0',
    'category': 'Tools',
    'description': """Feedback Management""",
    'author': 'Feedback Team SEED-8',
    'depends': [ 'web','base' ],
    'data': ['feedback_view.xml'],
    'installable': True,
    'auto_install': False,
}